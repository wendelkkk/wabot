const help1 = (prefix) => {

	return `
╭──────────────╮
        *COMANDOS FDS*
╰──────────────╯
 
➸ *${prefix}marcar*
➸ *${prefix}marcar2*
➸ *${prefix}marcar3*
➸ *${prefix}loli*
➸ *${prefix}loli1*
➸ *${prefix}hentai*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}akeno*
➸ *${prefix}malkova*
➸ *${prefix}nsfwloli*
➸ *${prefix}reislin*
➸ *${prefix}limpar*


════════════════════
*WENDEL NE OSH* 😳
sono da peste kkjkkkklk
════════════════════`

}
exports.help1 = help1

