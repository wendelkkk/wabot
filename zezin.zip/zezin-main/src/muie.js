const muie = (prefix) => {

	return `
╭──────────────╮
  *MOÇAS DE FAMÍLIA 😔🙏*
╰──────────────╯
 
➸ *${prefix}love lilih
➸ *${prefix}Brittney amber
➸ *${prefix}Kissasins
➸ *${prefix}Angela white
➸ *${prefix}Luxury girl
➸ *${prefix}Tiffany rain
➸ *${prefix}Canela skin
➸ *${prefix}Gabbie carter
➸ *${prefix}Lana Rhodes
➸ *${prefix}Katie kush
➸ *${prefix}Honey gold
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}Asa Akira
➸ *${prefix}Mini diva
➸ *${prefix}Loly lips
➸ *${prefix}malkova*
➸ *${prefix}reislin*


════════════════════
*WENDEL NE OSH* 😎🤙
════════════════════`

}
exports.muie = muie

